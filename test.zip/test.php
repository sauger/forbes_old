<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv=Content-Type content="text/html; charset=utf-8">
		<meta http-equiv=Content-Language content=zh-CN>
		<title>test</title>
		<?php
		include "frame.php";
		//redirect_login();
		//alert("aaaa'a'");
		$zip =  new ZipArchive();
		$filename = './test.zip';
		if($zip->open($filename,ZIPARCHIVE::CREATE)!== true){
			die('can\'t create the zip file');			
		}
		$zip->addFile('test.php');
		$zip->close();
		
		?>
	</head>
	<body>
		<div id="test">test</div>
	</body>
	<script>
		
		//alert(document.getElementById('test').type);
	</script>
</html>